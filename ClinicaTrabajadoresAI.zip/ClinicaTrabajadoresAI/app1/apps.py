from django.apps import AppConfig


class App1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'


class App1Config(AppConfig):
    name = 'app1'
