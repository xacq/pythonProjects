from django.db import models
from django.core.exceptions import ValidationError  # Agrega esta línea

# Create your models here.
class Contact(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField()
    subject = models.CharField(max_length=255)
    message = models.TextField()
    def __str__(self):
        return f"{self.name} - {self.subject}"


class Booking(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField()
    mobile = models.CharField(max_length=15)
    date = models.DateField()
    time = models.TimeField()
    num_tables = models.IntegerField()
    
    def clean(self):
        # Validar que el número de mesas no exceda el límite
        if self.num_tables < 1 or self.num_tables > 10:
            raise ValidationError("La cantidad de mesas debe estar entre 1 y 10.")
    def __str__(self):
        return f"{self.name}"


class Hamburguesa(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=255)
    precio = models.DecimalField(max_digits=8, decimal_places=2)
    descripcion = models.TextField()
    def __str__(self):
        return self.nombre

class Snack(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=255)
    precio = models.DecimalField(max_digits=8, decimal_places=2)
    descripcion = models.TextField()
    def __str__(self):
        return self.nombre

class Beverage(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=255)
    precio = models.DecimalField(max_digits=8, decimal_places=2)
    descripcion = models.TextField()
    def __str__(self):
        return self.nombre

    
class Pedidos(models.Model):
    id = models.AutoField(primary_key=True)
    hamburguesa = models.ForeignKey(Hamburguesa, on_delete=models.CASCADE)
    bebida = models.ForeignKey(Beverage, on_delete=models.CASCADE)
    snack = models.ForeignKey(Snack, on_delete=models.CASCADE)
    total = models.DecimalField(max_digits=8, decimal_places=2)
    user = models.CharField(max_length=255)
    def __str__(self):
        return str(self.id)


class Stock(models.Model):
    id = models.AutoField(primary_key=True)
    item = models.CharField(max_length=255)
    cantidad = models.IntegerField()
    precio = models.DecimalField(max_digits=8, decimal_places=2)
    def __str__(self):
        return f"{self.item} - Cantidad: {self.cantidad} - Precio: {self.precio}"