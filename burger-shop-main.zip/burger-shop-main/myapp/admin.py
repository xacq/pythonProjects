from django.contrib import admin
from .models import Hamburguesa, Snack, Beverage
from .models import Contact
from .models import Booking
from .models import Stock
from .models import Pedidos

class PedidosAdmin(admin.ModelAdmin):
    list_display = ('id', 'hamburguesa', 'bebida', 'snack', 'total', 'user')
    list_filter = ('hamburguesa', 'bebida', 'snack', 'user')
    search_fields = ('id', 'user')

admin.site.register(Pedidos, PedidosAdmin)

@admin.register(Stock)
class StockAdmin(admin.ModelAdmin):
    list_display = ['item', 'cantidad', 'precio']
    fields = ['item', 'cantidad', 'precio']
    

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'mobile', 'date', 'time', 'num_tables']
    fields = ['name', 'email','mobile', 'date', 'time', 'num_tables']  # Lista de campos que deseas mostrar en el formulario de administración
    
    
class ContactAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'subject', 'message'] 
    fields = ['name', 'email', 'subject', 'message']  # Lista de campos que deseas mostrar en el formulario de administración

admin.site.register(Contact, ContactAdmin)


@admin.register(Hamburguesa)
class HamburguesaAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'precio', 'descripcion']
    fields = ['nombre', 'precio', 'descripcion']

@admin.register(Snack)
class SnackAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'precio', 'descripcion']
    fields = ['nombre', 'precio', 'descripcion']

@admin.register(Beverage)
class BeverageAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'precio', 'descripcion']
    fields = ['nombre', 'precio', 'descripcion']