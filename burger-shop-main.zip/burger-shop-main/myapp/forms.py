from django import forms
from .models import Contact
from .models import Booking
from .models import Hamburguesa, Beverage, Snack
from .models import Hamburguesa, Snack, Beverage

class FoodCategoryForm(forms.Form):
    hamburguesa = forms.ModelChoiceField(
        queryset=Hamburguesa.objects.all(),
        label="Hamburguesa",
        empty_label="Seleccionar..."  # Optional: Add an empty option
    )
    snack = forms.ModelChoiceField(
        queryset=Snack.objects.all(),
        label="Snack",
        empty_label="Seleccionar..."
    )
    beverage = forms.ModelChoiceField(
        queryset=Beverage.objects.all(),
        label="Bebida",  # Translate "Beverage" to Spanish
        empty_label="Seleccionar..."
    )

class BookingForm(forms.ModelForm):
    num_tables = forms.ChoiceField(choices=[(i, f"{i}") for i in range(1, 11)])
    class Meta:
        model = Booking
        fields = ['name', 'email', 'mobile', 'date', 'time', 'num_tables']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
            'time': forms.TimeInput(attrs={'type': 'time'})
        }

class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = ('name', 'email', 'subject', 'message')
        

# Formulario simple para seleccionar categoría
class CategoriaForm(forms.Form):
    categoria = forms.ChoiceField(choices=[('hamburguesas', 'Hamburguesas'), ('snacks', 'Snacks'), ('bebidas', 'Bebidas')])


