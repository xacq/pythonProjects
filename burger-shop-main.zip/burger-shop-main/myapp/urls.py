"""URL configuration for delivery project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('',views.index,name="index"),
    path('about/', views.about, name="about"),
    path('feature/', views.feature, name="feature"),
    path('menu/', views.menu, name="menu"),
    path('booking/', views.booking, name="booking"),
    path('contact/', views.contact, name="contact"),
    path('success/', views.success_view, name='success'),
    path('success2/', views.success_view2, name='success2'),
    path('reserve/', views.booking, name='reserve_table'),
    path('reservation_success/', views.reservation_success, name='reservation_success'),
    path('pedido/', views.hamburguesas, name='menu'),
    path('envio_pedido/', views.pedido, name='envio_pedido'),
    path('login/',views.LoginPage,name='login'),
    path('logout/',views.LogoutPage,name='logout'),
    path('signup/',views.SignupPage,name='signup'),
    path('home/',views.HomePage,name='home'),
]