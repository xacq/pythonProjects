from django.shortcuts import render, redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from .forms import ContactForm
from .forms import BookingForm
from .models import Booking
from .models import Hamburguesa, Beverage, Snack
from .forms import FoodCategoryForm
from django.http import HttpResponse
from django.contrib.auth.models import User
from .models import Pedidos


@login_required(login_url='login')
def HomePage(request):
    # Obtener el nombre de usuario de la sesión
    username = request.session.get('username', None)
    if username:
        # Hacer algo con el nombre de usuario en la vista 'home'
        # Por ejemplo, pasarlo al contexto para mostrarlo en la plantilla
        context = {'username': username}
        return render(request, 'home.html', context)
    else:
        # Manejar el caso en el que el nombre de usuario no está en la sesión
        return HttpResponse("Debe iniciar sesión primero.")

def SignupPage(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        email=request.POST.get('email')
        pass1=request.POST.get('password1')
        pass2=request.POST.get('password2')
        if pass1!=pass2:
            return HttpResponse("Las contraseñas no coinciden!!")
        else:
            my_user=User.objects.create_user(uname,email,pass1)
            my_user.save()
            return redirect('login')
    return render (request,'signup.html')


def LoginPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            request.session['username'] = username
            return redirect('home')
        else:
            return HttpResponse ("Usuario y Contraseña incorrectos!!!")
    return render (request,'login.html')


def LogoutPage(request):
    logout(request)
    return redirect('index')


def pedido(request):
    if request.method == 'POST':
        # Obtener los datos del formulario
        hamburguesa_id = request.POST.get('hamburguesa')
        snack_id = request.POST.get('snack')
        bebida_id = request.POST.get('beverage')
        username = request.session.get('username', None)
        # Calcular el total (suponiendo que los precios estén definidos en los modelos Hamburguesa, Snack y Beverage)
        hamburguesa_precio = Hamburguesa.objects.get(id=hamburguesa_id).precio
        snack_precio = Snack.objects.get(id=snack_id).precio
        bebida_precio = Beverage.objects.get(id=bebida_id).precio
        total = hamburguesa_precio + snack_precio + bebida_precio

        # Crear una instancia del modelo Pedido y guardar en la base de datos
        pedido = Pedidos.objects.create(
            hamburguesa_id=hamburguesa_id,
            snack_id=snack_id,
            bebida_id=bebida_id,
            total=total,
            user=username
        )

        # Redireccionar a una página de confirmación u otra página deseada
        return redirect('success2')

    else:
        # Si la solicitud no es POST, redireccionar a una página de error u otra página deseada
        return redirect('menu.html')
    
    
    
# Vista para Hamburguesas
def hamburguesas(request):
    hamburguesas = Hamburguesa.objects.all()
    if request.method == 'POST':
        form = FoodCategoryForm(request.POST)
        if form.is_valid():
            selected_hamburguesa = form.cleaned_data['hamburguesa']
            # Aquí puedes realizar cualquier acción adicional con la hamburguesa seleccionada
    else:
        form = FoodCategoryForm()  # Create a new form instance
    
    context = {'hamburguesas': hamburguesas, 'form': form}
    return render(request, 'menu.html', context)

def snacks(request):
    snacks = Snack.objects.all()
    if request.method == 'POST':
        form = FoodCategoryForm(request.POST)
        if form.is_valid():
            selected_snack = form.cleaned_data['snack']
            # Aquí puedes realizar cualquier acción adicional con el snack seleccionado
    else:
        form = FoodCategoryForm()  # Create a new form instance
    
    context = {'snacks': snacks, 'form': form}
    return render(request, 'menu.html', context)

def beverages(request):
    beverages = Beverage.objects.all()
    if request.method == 'POST':
        form = FoodCategoryForm(request.POST)
        if form.is_valid():
            selected_beverage = form.cleaned_data['beverage']
            # Aquí puedes realizar cualquier acción adicional con la bebida seleccionada
    else:
        form = FoodCategoryForm()  # Create a new form instance
    
    context = {'beverages': beverages, 'form': form}
    return render(request, 'menu.html', context)


# Create your views here.
def index (request):
    return render(request, 'index.html')


def about (request):
    return render(request, 'about.html')


# Vista para la página de características (feature)
def feature(request):
    return render(request, 'feature.html')


# Vista para la página del equipo (team)
def team(request):
    return render(request, 'team.html')


# Vista para la página del menú (menu)
def menu(request):
    return render(request, 'menu.html')


# Vista para la página de reservas (booking)
def booking(request):
    username = request.session.get('username', None)
    context = {'username':username}
    return render(request, 'booking.html',context)


# Vista para la página de contacto (contact)
def contact(request):
    return render(request, 'contact.html')


def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()  # Save form data to database
            return redirect('success')  # Redirect to success page (optional)
    else:
        form = ContactForm()

    context = {'form': form}
    return render(request, 'contact.html', context)


def success_view(request):
    message = "¡Tu informacion se ha enviado correctamente!"
    message2 = " Gracias por preferirnos...!"
    return render(request, 'contact.html', {'message': message,'message2':message2})

def success_view2(request):
    message = "¡Tu solicitud se ha enviado correctamente!"
    message2 = " Gracias por preferirnos...!"
    return render(request, 'menu.html', {'message': message,'message2':message2})


from django.shortcuts import render, redirect
from .forms import BookingForm
from .models import Booking

def booking(request):
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            new_booking = form.save(commit=False)

            # Obtener todas las reservas existentes para la misma mesa
            existing_bookings = Booking.objects.filter(num_tables=new_booking.num_tables)

            # Verificar si alguna reserva existente se superpone con la nueva reserva
            for booking in existing_bookings:
                if booking.date == new_booking.date and booking.time == new_booking.time:
                    # Si hay una superposición, mostrar un mensaje de error
                    error_message = "La mesa ya está reservada para esta fecha y hora. Por favor, elija una fecha u hora diferente."
                    return render(request, 'booking.html', {'form': form, 'error_message': error_message})

            new_booking.save()
            return redirect('reservation_success')  # Redirige a la página de éxito después de guardar
    else:
        # Establecer el valor por defecto del campo 'name' en el formulario
        default_username = request.session.get('username', None)
        form = BookingForm(initial={'name': default_username})
        
    context = {'form': form}
    return render(request, 'booking.html', context)


def reservation_success(request):
    message = "¡Tu reservación se ha realizado correctamente!"
    message2 = " Gracias por preferirnos...!"
    context = {'message': message, 'message2': message2}
    return render(request, 'booking.html', context)



