from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name="index"),
    path('login/',views.LoginPage,name='login'),
    path('logout/',views.LogoutPage,name='logout'),
    path('signup/',views.SignupPage,name='signup'),
    path('home/',views.HomePage,name='home'),
    path('edit/',views.Edit,name='edit'),
    path('games/',views.games,name='games'),
    path('activity/',views.activity,name='activity'),
    path('help/',views.help,name='help'),
    path('pregunta1/',views.pregunta1,name='pregunta1'),
    path('pregunta2/',views.pregunta2,name='pregunta2'),
    path('pregunta3/',views.pregunta3,name='pregunta3'),
    path('pregunta4/',views.pregunta4,name='pregunta4'),
    path('pregunta5/',views.pregunta5,name='pregunta5'),
    path('pregunta6/',views.pregunta6,name='pregunta6'),
    path('pregunta7/',views.pregunta7,name='pregunta7'),
    path('pregunta8/',views.pregunta8,name='pregunta8'),
    path('pregunta9/',views.pregunta9,name='pregunta9'),
    path('pregunta10/',views.pregunta10,name='pregunta10'),
    path('snake/',views.snake,name='snake'),
    path('pong/',views.pong,name='pong'),
    path('save_score/', views.save_score, name='save_score'),
]