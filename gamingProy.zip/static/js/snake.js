;(function() {

    // Clase Random para generar números aleatorios
    class Random {
        // Genera un número aleatorio entre 'inicio' y 'final'
        static get(inicio, final) {
            return Math.floor(Math.random() * final) + inicio;
        }
    }

    // Clase Mazas que representa la comida de la serpiente
    class Mazas {
        constructor(x, y) {
            this.x = x;
            this.y = y;
            this.width = 15;
            this.height = 15;
        }

        // Dibuja la comida en el canvas
        draw() {
            ctx.fillRect(this.x, this.y, this.width, this.height);
        }

        // Genera una nueva comida dentro de los límites del canvas
        static genera() {
            return new Mazas(Random.get(0, 580), Random.get(0, 380));
        }
    }

    // Clase Cuadrado que representa cada segmento de la serpiente
    class Cuadrado {
        constructor(x, y) {
            this.x = x;
            this.y = y;
            this.width = 15;
            this.height = 15;
            this.back = null; // Referencia al segmento siguiente de la serpiente
        }

        // Dibuja el segmento y cualquier segmento siguiente
        dibujar() {
            ctx.fillRect(this.x, this.y, this.width, this.height);
            if (this.hasBack()) {
                this.back.dibujar();
            }
        }

        // Añade un nuevo segmento a la serpiente
        add() {
            if (this.hasBack()) return this.back.add();
            this.back = new Cuadrado(this.x, this.y);
        }

        // Verifica si este segmento tiene un segmento siguiente
        hasBack() {
            return this.back !== null;
        }

        // Copia la posición del segmento anterior al siguiente
        copy() {
            if (this.hasBack()) {
                this.back.copy();
                this.back.x = this.x;
                this.back.y = this.y;
            }
        }

        // Mueve el segmento hacia la derecha
        right() {
            this.copy();
            this.x += 15;
        }

        // Mueve el segmento hacia la izquierda
        left() {
            this.copy();
            this.x -= 15;
        }

        // Mueve el segmento hacia abajo
        down() {
            this.copy();
            this.y += 15;
        }

        // Mueve el segmento hacia arriba
        up() {
            this.copy();
            this.y -= 15;
        }

        // Verifica si el segmento choca con otro segmento o con los bordes del canvas
        hit(cabeza, segundo) {
            segundo = false;
            if (this === cabeza && !this.hasBack()) return false;
            if (this === cabeza) return this.back.hit(cabeza, true);
            if (segundo && !this.hasBack()) return false;
            if (segundo) return this.back.hit(cabeza);
            if (this.hasBack()) {
                return cabezaHit(this, cabeza) || this.back.hit(cabeza);
            }
            return cabezaHit(this, cabeza);
        }

        // Verifica si el segmento choca con los bordes del canvas
        hitBorder() {
            return this.x > 580 || this.x < 0 || this.y > 380 || this.y < 0;
        }
    }

    // Clase Snake que representa la serpiente completa
    class Snake {
        constructor() {
            this.cabeza = new Cuadrado(100, 0);
            this.dibujar();
            this.direcion = "right";
            // Añade varios segmentos a la serpiente
            for (let i = 0; i < 6; i++) {
                this.cabeza.add();
            }
        }

        // Dibuja la serpiente
        dibujar() {
            this.cabeza.dibujar();
        }

        // Cambia la dirección de la serpiente a la derecha
        right() {
            if (this.direcion === "left") return;
            this.direcion = "right";
        }

        // Cambia la dirección de la serpiente a la izquierda
        left() {
            if (this.direcion === "right") return;
            this.direcion = "left";
        }

        // Cambia la dirección de la serpiente hacia arriba
        up() {
            if (this.direcion === "down") return;
            this.direcion = "up";
        }

        // Cambia la dirección de la serpiente hacia abajo
        down() {
            if (this.direcion === "up") return;
            this.direcion = "down";
        }

        // Mueve la serpiente en la dirección actual
        move() {
            if (this.direcion === "up") return this.cabeza.up();
            if (this.direcion === "down") return this.cabeza.down();
            if (this.direcion === "right") return this.cabeza.right();
            if (this.direcion === "left") return this.cabeza.left();
        }

        // Añade un segmento a la serpiente (cuando come)
        eat() {
            this.cabeza.add();
        }

        // Verifica si la serpiente está muerta (chocó consigo misma o con los bordes)
        dead() {
            return this.cabeza.hit(this.cabeza) || this.cabeza.hitBorder();
        }
    }

    // Variables para inicializar el juego
    var canvas = document.getElementById('canvas');
    var ctx = canvas.getContext('2d');
    var puntos = 0.0;
    var snake = new Snake();
    var foods = [];

    // Evento que escucha las teclas presionadas para mover la serpiente
    window.addEventListener("keydown", function(ev) {
        if (ev.keyCode > 36 && ev.keyCode < 41) ev.preventDefault();
        if (ev.keyCode === 40) return snake.down();
        else if (ev.keyCode === 39) return snake.right();
        else if (ev.keyCode === 38) return snake.up();
        else if (ev.keyCode === 37) return snake.left();
        else ev.preventDefault()
        return false;
    });

    // Intervalo para actualizar el estado del juego
    var animacion = setInterval(function() {
        snake.move();
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        snake.dibujar();
        drawMazas();
        ctx.font = "bold 16px architects daughter";
        ctx.fillStyle = "#000";
        ctx.fillText("PUNTOS: " + puntos, 10, canvas.height - 10);

        if (snake.dead()) {
            clearInterval(animacion);
            enviarPuntaje(puntos, 'snake');  // Envía el puntaje al servidor

            if (puntos >= 10) {
                showModal(); // Muestra el modal si el puntaje es 10 o más
            }

            var reloadButton = document.getElementById('reloadButton');
            //reloadButton.style.display = 'block'; // Muestra el botón de recarga
            reloadButton.onclick = function() {
                window.location.reload(); // Recarga la página cuando el botón es pulsado
            };
        }
    }, 1000 / 15);

    // Intervalo para generar comida en el juego
    setInterval(function() {
        var food = Mazas.genera();
        foods.push(food);
        setTimeout(function() {
            // Elimina la comida después de 10 segundos
            borraMazas(food);
        }, 10000);
    }, 4000);

    // Dibuja todas las comidas en el canvas
    function drawMazas() {
        for (var index in foods) {
            var food = foods[index];
            if (typeof food !== "undefined") {
                ctx.fillStyle = 'red';
                food.draw();
                if (hit(food, snake.cabeza)) {
                    snake.eat();
                    borraMazas(food);
                    puntos++;
                }
            }
        }
    }

    // Elimina una comida del array de comidas
    function borraMazas(food) {
        foods = foods.filter(function(f) {
            return food != f;
        });
    }

    // Verifica si dos cuadrados chocan
    function cabezaHit(cuadrado_1, cuadrado_2) {
        return cuadrado_1.x == cuadrado_2.x && cuadrado_1.y == cuadrado_2.y;
    }

    // Verifica si dos objetos chocan
    function hit(a, b) {
        var hit = false;
        // Colisiones horizontales
        if (b.x + b.width >= a.x && b.x < a.x + a.width) {
            // Colisiones verticales
            if (b.y + b.height >= a.y && b.y < a.y + a.height) {
                hit = true;
            }
        }
        // Colisión de a con b
        if (b.x <= a.x && b.x + b.width >= a.x + a.width) {
            if (b.y <= a.y && b.y + b.height >= a.y + a.height) {
                hit = true;
            }
        }
        // Colisión de b con a
        if (a.x <= b.x && a.x + a.width >= b.x + b.width) {
            if (a.y <= b.y && a.y + a.height >= b.y + b.height) {
                hit = true;
            }
        }
        return hit;
    }

    // Envía el puntaje al servidor
    function enviarPuntaje(puntaje, actividad) {
        fetch('/save_score/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-CSRFToken': getCookie('csrftoken')  // Incluye el token CSRF
            },
            body: `score=${puntaje}&activity=${actividad}`
        })
        .then(response => response.json())
        .then(data => {
            console.log(data);
        })
        .catch(error => console.error('Error:', error));
    }

    // Obtiene el valor de una cookie
    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
})();
