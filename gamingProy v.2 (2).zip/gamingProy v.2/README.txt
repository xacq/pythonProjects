INSTRUCCIONES

ENTORNO DIANGO
PARA EJECUTAR LA APP
py manage.py runserver

CONFIGURACION DE MODELOS
LUEGO DE GENERAR UN MODEL
py manage.py makemigrations
python manage.py migrate
PARA ELIMINAR UN MODEL
python manage.py showmigrations
python manage.py migrate webSite 0003_delete_gamesession --fake