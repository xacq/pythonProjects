// Obtención de los elementos del DOM necesarios
const ball = document.getElementById('ball');
const bar1 = document.getElementById('bar1');
const bar2 = document.getElementById('bar2');
const gameArea = document.getElementById('gameArea');
const reloadButton = document.getElementById('reloadButton');
const scoreDisplay = document.getElementById('score'); // Elemento para mostrar el puntaje

// Sonidos del juego
const hitSound = new Audio("{% static 'sound/ping.mp3' %}");
const scoreSound = new Audio("{% static 'sound/score.wav' %}");
const winSound = new Audio("{% static 'sound/win.wav' %}");

// Inicialización de variables para el movimiento de la pelota y las barras
let ballDirectionX = 1; // Dirección de la pelota en el eje X
let ballDirectionY = 1; // Dirección de la pelota en el eje Y
let ballSpeed = 8; // Velocidad de la pelota
let barSpeed = 9; // Velocidad de la barra del jugador
let computerSpeed = 9; // Velocidad de la barra del ordenador
let height = gameArea.clientHeight; // Altura del área de juego
let width = gameArea.clientWidth; // Ancho del área de juego
let playerScore = 0; // Contador de puntos del jugador
let computerScore = 0; // Contador de puntos del computador

// Objeto para rastrear el estado de las teclas del jugador
const player1 = { keyPress: false, keyCode: null };

// Función para iniciar el juego, llama a updateGame 60 veces por segundo
function startGame() {
    setInterval(updateGame, 1000 / 60);
}

// Función que actualiza el estado del juego en cada cuadro
function updateGame() {
    moveBall(); // Mueve la pelota
    movePlayerBar(); // Mueve la barra del jugador
    moveComputerBar(); // Mueve la barra del ordenador
    checkCollision(); // Verifica colisiones
}

// Función que mueve la pelota
function moveBall() {
    ball.style.left = (ball.offsetLeft + ballSpeed * ballDirectionX) + 'px';
    ball.style.top = (ball.offsetTop + ballSpeed * ballDirectionY) + 'px';

    // Rebotar la pelota si toca el borde superior o inferior
    if (ball.offsetTop <= 5 || ball.offsetTop + ball.clientHeight >= height) {
        ballDirectionY *= -1;
        hitSound.play();
    }
}

// Función que verifica las colisiones de la pelota con las barras y los bordes laterales
function checkCollision() {
    if (collide(bar1)) {
        ballDirectionX = 1; // Rebote en la barra del jugador
        hitSound.play();
    } else if (collide(bar2)) {
        ballDirectionX = -1; // Rebote en la barra del ordenador
        hitSound.play();
    }

    // Verificar si la pelota sale por los bordes laterales y actualizar el puntaje
    if (ball.offsetLeft <= 5) {
        computerScore++;
        updateScore();
        scoreSound.play();
        if (computerScore >= 5) {
            alert("¡El computador ha ganado!");
            winSound.play();
            resetGame();
        } else {
            alert("Computador gana punto!");
            resetBall();
        }
    }

    if (ball.offsetLeft + ball.clientWidth >= width) {
        playerScore++;
        updateScore();
        scoreSound.play();
        if (playerScore >= 5) {
            alert("¡El jugador ha ganado!");
            winSound.play();
            resetGame();
        } else {
            alert("Usuario gana punto!");
            resetBall();
        }
    }
}

// Función que detecta colisiones entre la pelota y una barra
function collide(bar) {
    return ball.offsetLeft < bar.offsetLeft + bar.clientWidth &&
           ball.offsetLeft + ball.clientWidth > bar.offsetLeft &&
           ball.offsetTop < bar.offsetTop + bar.clientHeight &&
           ball.offsetTop + ball.clientHeight > bar.offsetTop;
}

// Función que mueve la barra del jugador
function movePlayerBar() {
    if (player1.keyPress) {
        if (player1.keyCode === 38 && bar1.offsetTop > 30) { // Flecha arriba
            bar1.style.top = (bar1.offsetTop - barSpeed) + 'px';
        } else if (player1.keyCode === 40 && bar1.offsetTop + bar1.clientHeight < (height+35)) { // Flecha abajo
            bar1.style.top = (bar1.offsetTop + barSpeed) + 'px';
        }
    }
}

// Función que mueve la barra del ordenador
function moveComputerBar() {
    if (ball.offsetTop > bar2.offsetTop + bar2.clientHeight / 2 && bar2.offsetTop + bar2.clientHeight < height) {
        bar2.style.top = (bar2.offsetTop + computerSpeed) + 'px';
    } else if (ball.offsetTop < bar2.offsetTop + bar2.clientHeight / 2 && bar2.offsetTop > 0) {
        bar2.style.top = (bar2.offsetTop - computerSpeed) + 'px';
    }
}

// Función que reinicia la posición de la pelota
function resetBall() {
    ball.style.left = '50%'; // Coloca la pelota en el centro
    ball.style.top = '50%';
    ballDirectionX *= -1; // Cambia la dirección de la pelota
    ballDirectionY = 1;
}

// Función que reinicia el juego
function resetGame() {
    resetBall(); // Resetea la posición de la pelota
    playerScore = 0; // Resetea el contador de puntos del jugador
    computerScore = 0; // Resetea el contador de puntos del computador
    updateScore(); // Actualiza el puntaje en pantalla
}

// Función que actualiza el puntaje en pantalla
function updateScore() {
    scoreDisplay.textContent = `Jugador: ${playerScore} - Computador: ${computerScore}`;
}

// Event listener para las teclas presionadas
document.addEventListener('keydown', function(e) {
    if (e.keyCode === 38 || e.keyCode === 40) { // Flecha arriba o abajo
        player1.keyPress = true;
        player1.keyCode = e.keyCode;
    }
});

// Event listener para las teclas soltadas
document.addEventListener('keyup', function(e) {
    if (e.keyCode === 38 || e.keyCode === 40) { // Flecha arriba o abajo
        player1.keyPress = false;
    }
});

// Event listener para el botón de recarga
reloadButton.addEventListener('click', () => {
    resetGame(); // Reinicia el juego
});

// Inicia el juego
startGame();
