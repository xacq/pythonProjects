from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class rol(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rol = models.CharField(max_length=100)
    
    def __str__(self):
        return f'rol: {self.rol}'



class StudentActivity(models.Model):
    # El campo 'id' se crea automáticamente como una clave primaria
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Relación con el modelo User de Django
    activity_number = models.IntegerField()  # Número de la actividad
    grade = models.FloatField()  # Calificación de la actividad (puede ser flotante para permitir decimales)
    fecha_hora = models.DateTimeField(default=timezone.now)  # Fecha y hora actual por defecto

    def __str__(self):
        return f'Actividad {self.activity_number} - Usuario: {self.user.username} - Calificación: {self.grade} - Fecha: {self.fecha_hora}'


#MODELO PARA TENER EL PUNTAJE DEL USUARIO Y EL NUMERO DE VIDAS
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    score = models.IntegerField(default=0)
    lives = models.IntegerField(default=3)
    last_updated = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.user.username


#MODELOS PARA CAD UNA DE LAS ACTIVIDADES
class ACT1(models.Model):
    # El campo 'id' se crea automáticamente como una clave primaria
    respuesta = models.IntegerField()  # Campo para almacenar la respuesta como entero
    descripcion = models.TextField()    # Campo para almacenar la descripción como cadena de texto
    pregunta = models.TextField(default="¿Qué tipo de triángulo se dibujará según sus ángulos...?")  # Campo para almacenar las preguntas con un valor por defecto

    def __str__(self):
        return f'ACT1 {self.id} - Respuesta: {self.respuesta}'


class ACT2(models.Model):
    # El campo 'id' se crea automáticamente como una clave primaria
    respuesta = models.IntegerField()  # Campo para almacenar la respuesta como entero
    descripcion = models.TextField()    # Campo para almacenar la descripción como cadena de texto
    pregunta = models.TextField(default="¿Qué tipo de triángulo se dibujará según sus lados...?")  # Campo para almacenar las preguntas con un valor por defecto

    def __str__(self):
        return f'ACT2 {self.id} - Respuesta: {self.respuesta}'
    
    
class ACT3(models.Model):
    respuesta = models.IntegerField(default=1)  # Campo para almacenar la respuesta como entero
    valor_a = models.IntegerField()
    valor_b = models.IntegerField()
    valor_x = models.IntegerField()
    pregunta = models.TextField(default="Calcula el valor del angulo X...!")
    
    def __str__(self):
        return f'valor_a {self.id}: {self.valor_a}'


class ACT4(models.Model):
    angulo_interno = models.IntegerField()
    angulo_externo = models.IntegerField()
    pregunta = models.TextField(default="Calcula el valor del angulo externo θ...!")

    def __str__(self):
        return f'ACT4 {self.id} - Ángulo Interno: {self.angulo_interno}, Ángulo Externo: {self.angulo_externo}'

      
class ACT5(models.Model):
    lado_a = models.FloatField()
    angulo = models.IntegerField()
    pregunta = models.TextField(default="Calcula el valor de la hipotenusa del triángulo...!")

    def __str__(self):
        return f'ACT5 {self.id} - Lado a: {self.lado_a}, Ángulo: {self.angulo}'    
    

class ACT6(models.Model):
    triangulo = models.IntegerField()  # 1, 2, 3 o 4 (representando el tipo de triángulo)
    angulo_a = models.IntegerField() 
    angulo_b = models.IntegerField()
    angulo_teta = models.IntegerField() 
    pregunta = models.TextField(default="Calcula el valor del ángulo teta...!")

    def __str__(self):
        return f'ACT6 {self.id} - Triángulo: {self.triangulo}, Ángulo A: {self.angulo_a}, Ángulo B: {self.angulo_b}'
    
    
class ACT7(models.Model):
    lado_a = models.IntegerField() 
    lado_b = models.IntegerField()
    hipotenusa = models.IntegerField() 
    pregunta = models.TextField(default="Calcula el valor de la hipotenusa...!")

    def __str__(self):
        return f'ACT7 {self.id} - Lado A: {self.lado_a}, Lado B: {self.lado_b}, Hipotenusa: {self.hipotenusa}'
    
    
class ACT8(models.Model):
    lado_a = models.IntegerField() 
    lado_b = models.IntegerField()
    hipotenusa = models.IntegerField() 
    pregunta = models.TextField(default="Calcula el valor del Cateto a ...!")

    def __str__(self):
        return f'ACT8 {self.id} - Lado A: {self.lado_a}, Lado B: {self.lado_b}, Hipotenusa: {self.hipotenusa}'
    
    
class ACTIVIDAD9(models.Model):
    respuesta = models.CharField(max_length=255)  # Agrega longitud máxima
    pregunta = models.TextField(default="Formula para calcular la Tangente de θ ...!")

    def __str__(self):
        return f'ACTIVIDAD9 {self.id} - respuesta: {self.respuesta}, pregunta: {self.pregunta}'


class ACT10(models.Model):
    respuesta = models.CharField(max_length=255)  # Agrega longitud máxima
    pregunta = models.TextField(default="Formula para calcular el valor del Cateto b ...!")

    def __str__(self):
        return f'ACT10 {self.id} - respuesta: {self.respuesta}, pregunta: {self.pregunta}'