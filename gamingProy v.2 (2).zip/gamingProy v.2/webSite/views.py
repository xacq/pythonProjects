import json
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .models import *
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from django.utils import timezone
import random
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse


def index (request):
    return render(request, 'index.html')

def onelive (request):
    return render(request, 'onelive.html')

def help (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'help.html',context)

def games (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'gamesgaming.html',context)

def snake (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'snakegaming.html',context)

@login_required
@csrf_exempt
def actualizar_puntaje_y_vidas(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            puntos = data.get('puntos')
            # Actualiza el puntaje y las vidas del usuario en la base de datos
            user_profile = UserProfile.objects.get(user=request.user)
            user_profile.lives += 1
            user_profile.save()
            response_data = {
                'status': 'success',
                'message': 'Puntaje y vidas actualizados correctamente.',
                'redirect_url': '/onelive/'  # La URL a la que deseas redirigir
            }
            return JsonResponse(response_data)
        except json.JSONDecodeError:
            return JsonResponse({'status': 'error', 'message': 'JSON inválido'}, status=400)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    return JsonResponse({'status': 'error', 'message': 'Método no permitido'}, status=405)

def pong (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'ponggaming.html',context)

@login_required
@csrf_exempt
def actualizar_puntaje_y_vidas_pong(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            puntos = data.get('puntos')
            # Actualiza el puntaje y las vidas del usuario en la base de datos  
            user_profile = UserProfile.objects.get(user=request.user)
            user_profile.lives += 1
            user_profile.save()
            response_data = {
                'status': 'success',
                'message': 'Puntaje y vidas actualizados correctamente.',
                'redirect_url': '/onelive/'  # La URL a la que deseas redirigir
            }
            return JsonResponse(response_data)
        except json.JSONDecodeError:
            return JsonResponse({'status': 'error', 'message': 'JSON inválido'}, status=400)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    return JsonResponse({'status': 'error', 'message': 'Método no permitido'}, status=405)

@login_required
def activity (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'activitygaming.html',context)

@login_required
def over (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'over.html',context)

@login_required
def retroact1 (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'retroact1.html',context)

@login_required
def retroact2 (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'retroact2.html',context)

@login_required
def retroact3 (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'retroact3.html',context)

@login_required
def retroact4 (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'retroact4.html',context)

@login_required
def retroact5 (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'retroact5.html',context)

@login_required
def retroact6 (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'retroact6.html',context)

@login_required
def retroact7 (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'retroact7.html',context)

@login_required
def retroact8 (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'retroact8.html',context)

@login_required
def retroact9 (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'retroact9.html',context)

@login_required
def retroact10 (request):
    username = request.session.get('username', None)
    context = {'username': username}
    return render(request, 'retroact10.html',context)

@login_required(login_url='login')  # Redirige a 'login' si no está autenticado
def HomePage(request):
    # Obtén el nombre de usuario del usuario logueado desde la sesión
    username = request.session.get('username', None)
    if username:
        # Obtén el objeto User correspondiente al nombre de usuario
        user = get_object_or_404(User, username=username)
        # Filtra las actividades para que solo se muestren las del usuario actual
        activities = StudentActivity.objects.filter(user=user).order_by('-fecha_hora')
        # Prepara el contexto para enviar al template
        context = {
            'username': username,
            'activities': activities
        }
        return render(request, 'homegaming.html', context)
    else:
        tipo=3
        error_message = "Debe iniciar sesión primero...!"
        context = {
            'tipo': tipo , 
            'error_message' : error_message
        }                    
        return render(request, 'error.html', context)
    
@login_required(login_url='login')
def Edit(request):
    username = request.session.get('username', None)
    if username:
        context = {'username': username}
        return render(request, 'editgaming.html', context)
    else:
        return HttpResponse("Debe iniciar sesión primero.")

def SignupPage(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        email = request.POST.get('email')
        pass1 = request.POST.get('password1')
        pass2 = request.POST.get('password2')

        error_message = None

        if User.objects.filter(username=uname).exists():
            error_message = "Ese nombre de usuario ya está en uso."
            tipo=2
            context = {
                'tipo': tipo , 
                'error_message' : error_message
                }                    
            return render(request, 'error.html', context)
        else:
            if pass1 != pass2:
                tipo=2
                error_message = "Las contraseñas no coinciden...!"
                context = {
                    'tipo': tipo , 
                    'error_message' : error_message
                }                    
                return render(request, 'error.html', context)
            else:
                try:
                    # Create the user with password hashing
                    my_user = User.objects.create_user(username=uname, password=pass1, email=email)
                    my_user.save()
                    
                    # Create the UserProfile for the new user
                    UserProfile.objects.create(user=my_user)
                    
                    return redirect('login')  # Redirect to your login view
                except Exception as e:
                    tipo=2
                    error_message = "Error al crear el usuario: " + str(e)
                    context = {
                        'tipo': tipo , 
                        'error_message' : error_message
                    }                    
                    return render(request, 'error.html', context)

    return render(request, 'signupgaming.html')

#FUNCION PARA PERMITIR EL INGRESO DEL USUARIO
def LoginPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('password')
        user=authenticate(request,username=username,password=pass1)#vERIFICA LA EXISTENCIA DEL USUARIO INGRESADO
        if user is not None: #SI EL USUARIO EXISTE
            login(request,user)
            request.session['username'] = username
            return redirect('home')
        else:
            tipo=1
            error_message = "Usuario o contraseña no existen...!"
            context = {
                'tipo': tipo , 
                'error_message' : error_message
            }
            return render(request, 'error.html',context)
    return render (request,'logingaming.html')

def LogoutPage(request):
    logout(request)
    return redirect('index')


#CONTROLADOR DE LA ACTIVIDAD 1
@login_required
def act1(request):
    # Obtener el perfil del usuario
    user_profile = UserProfile.objects.get(user=request.user)
    
    # Comprobar si el usuario tiene vidas restantes
    if user_profile.lives <= 0:
        return redirect('over')

    if request.method == 'POST':
        try:
            user_answer = int(request.POST.get('answer', 0))
            triangle_type = int(request.POST.get('triangleType', 0))
        except ValueError:
            return HttpResponse("Error en la respuesta del formulario.")

        if user_answer == triangle_type:
            user_profile.score += 1
            grade = 1
        else:
            user_profile.lives -= 1
            grade = 0

        user_profile.save()
        
        StudentActivity.objects.create(
            user=request.user,
            activity_number=1,
            grade=grade,
            fecha_hora=timezone.now()
        )

        if user_profile.lives <= 0:
            return redirect('over')

        template = 'act1success.html' if user_answer == triangle_type else 'retroact1.html'
        context = {
            'username': request.user.username,
            'result': 'correct' if user_answer == triangle_type else 'incorrect',
            'lives': user_profile.lives,
            'score': user_profile.score
        }
        return render(request, template, context)

    all_answers = list(ACT1.objects.values_list('respuesta', flat=True))
    random_answer = random.choice(all_answers) if all_answers else None
    pregunta = ACT1.objects.first().pregunta if ACT1.objects.exists() else None

    context = {
        'username': request.user.username,
        'triangleType': random_answer,
        'pregunta': pregunta,
        'lives': user_profile.lives,
        'score': user_profile.score
    }
    return render(request, 'act1.html', context)

#CONTROLADOR DE LA ACTIVIDAD 2
@login_required
def act2(request):
    # Obtener el perfil del usuario
    user_profile = UserProfile.objects.get(user=request.user)

    # Comprobar si el usuario tiene vidas restantes
    if user_profile.lives <= 0:
        return redirect('over')

    if request.method == 'POST':
        try:
            user_answer = int(request.POST.get('answer', 0))
            triangle_type = int(request.POST.get('triangleType', 0))
        except ValueError:
            return HttpResponse("Error en la respuesta del formulario.")

        if user_answer == triangle_type:
            user_profile.score += 1
            grade = 1
        else:
            user_profile.lives -= 1
            grade = 0

        user_profile.save()
        
        StudentActivity.objects.create(
            user=request.user,
            activity_number=2,
            grade=grade,
            fecha_hora=timezone.now()
        )

        if user_profile.lives <= 0:
            return redirect('over')

        template = 'act2success.html' if user_answer == triangle_type else 'retroact2.html'
        context = {
            'username': request.user.username,
            'result': 'correct' if user_answer == triangle_type else 'incorrect',
            'lives': user_profile.lives
        }
        return render(request, template, context)

    all_answers = list(ACT2.objects.values_list('respuesta', flat=True))
    random_answer = random.choice(all_answers) if all_answers else None
    pregunta = ACT2.objects.first().pregunta if ACT2.objects.exists() else None

    context = {
        'username': request.user.username,
        'triangleType': random_answer,
        'pregunta': pregunta,
        'lives': user_profile.lives,
        'score': user_profile.score
    }
    return render(request, 'act2.html', context)

#CONTROLADOR DE LA ACTIVIDAD 3
@login_required
def act3(request):
    # Obtener el perfil del usuario
    user_profile = UserProfile.objects.get(user=request.user)

    # Comprobar si el usuario tiene vidas restantes
    if user_profile.lives <= 0:
        return redirect('over')

    if request.method == 'POST':
        try:
            user_answer = int(request.POST.get('answer', 0))
            valor_x = int(request.POST.get('valor_x', 0))
        except ValueError:
            return HttpResponse("Error en la respuesta del formulario.")

        if user_answer == valor_x:
            user_profile.score += 1
            grade = 1
        else:
            user_profile.lives -= 1
            grade = 0

        user_profile.save()

        StudentActivity.objects.create(
            user=request.user,
            activity_number=3,
            grade=grade,
            fecha_hora=timezone.now()
        )

        if user_profile.lives <= 0:
            return redirect('over')

        template = 'act3success.html' if user_answer == valor_x else 'retroact3.html'
        context = {
            'username': request.user.username,
            'result': 'correct' if user_answer == valor_x else 'incorrect',
            'lives': user_profile.lives
        }
        return render(request, template, context)

    # Obtener un registro aleatorio de ACT3
    all_records = list(ACT3.objects.all())
    random_record = random.choice(all_records) if all_records else None

    context = {
        'username': request.user.username,
        'lives': user_profile.lives,
        'score': user_profile.score,
        'random_record': random_record
    }
    return render(request, 'act3.html', context)

#CONTROLADOR DE LA ACTIVIDAD 4
@login_required
def act4(request):
    # Obtener el perfil del usuario
    user_profile = UserProfile.objects.get(user=request.user)

    # Comprobar si el usuario tiene vidas restantes
    if user_profile.lives <= 0:
        return redirect('over')

    if request.method == 'POST':
        try:
            user_answer = int(request.POST.get('answer', 0))
            angulo_externo = int(request.POST.get('angulo_externo', 0))
        except ValueError:
            return HttpResponse("Error en la respuesta del formulario.")

        if user_answer == angulo_externo:
            user_profile.score += 1
            grade = 1
            template = 'act4success.html'
            result = 'correct'
        else:
            user_profile.lives -= 1
            grade = 0
            template = 'retroact4.html'
            result = 'incorrect'

        user_profile.save()

        StudentActivity.objects.create(
            user=request.user,
            activity_number=4,
            grade=grade,
            fecha_hora=timezone.now()
        )

        if user_profile.lives <= 0:
            return redirect('over')

        context = {
            'username': request.user.username,
            'result': result,
            'lives': user_profile.lives
        }
        return render(request, template, context)

    # Obtener un registro aleatorio de ACT4
    random_record = ACT4.objects.order_by('?').first()
    context = {
        'username': request.user.username,
        'lives': user_profile.lives,
        'score': user_profile.score,
        'random_record': random_record
    }
    return render(request, 'act4.html', context)

#CONTROLADOR DE LA ACTIVIDAD 5
@login_required
def act5(request):
    # Obtener el perfil del usuario
    user_profile = UserProfile.objects.get(user=request.user)

    # Comprobar si el usuario tiene vidas restantes
    if user_profile.lives <= 0:
        return redirect('over')

    if request.method == 'POST':
        try:
            user_answer = int(request.POST.get('answer', 0))
            angulo = int(request.POST.get('angulo', 0))
        except ValueError:
            return HttpResponse("Error en la respuesta del formulario.")

        if user_answer == angulo:
            user_profile.score += 1
            grade = 1
            template = 'act5success.html'
            result = 'correct'
        else:
            user_profile.lives -= 1
            grade = 0
            template = 'retroact5.html'
            result = 'incorrect'

        user_profile.save()

        StudentActivity.objects.create(
            user=request.user,
            activity_number=5,
            grade=grade,
            fecha_hora=timezone.now()
        )

        if user_profile.lives <= 0:
            return redirect('over')

        context = {
            'username': request.user.username,
            'result': result,
            'lives': user_profile.lives
        }
        return render(request, template, context)

    # Obtener un registro aleatorio de ACT5
    random_record = ACT5.objects.order_by('?').first()
    context = {
        'username': request.user.username,
        'lives': user_profile.lives,
        'score': user_profile.score,
        'random_record': random_record
    }
    return render(request, 'act5.html', context)

#CONTROLADOR DE LA ACTIVIDAD 6
@login_required
def act6(request):
    # Obtener el perfil del usuario
    user_profile = UserProfile.objects.get(user=request.user)

    # Comprobar si el usuario tiene vidas restantes
    if user_profile.lives <= 0:
        return redirect('over')

    if request.method == 'POST':
        try:
            user_answer = int(request.POST.get('answer', 0))
            angulo = int(request.POST.get('angulo', 0))
        except ValueError:
            return HttpResponse("Error en la respuesta del formulario.")

        if user_answer == angulo:
            user_profile.score += 1
            grade = 1
            template = 'act6success.html'
            result = 'correct'
        else:
            user_profile.lives -= 1
            grade = 0
            template = 'retroact6.html'
            result = 'incorrect'

        user_profile.save()

        StudentActivity.objects.create(
            user=request.user,
            activity_number=6,
            grade=grade,
            fecha_hora=timezone.now()
        )

        if user_profile.lives <= 0:
            return redirect('over')

        context = {
            'username': request.user.username,
            'result': result,
            'lives': user_profile.lives
        }
        return render(request, template, context)

    # Obtener un registro aleatorio de ACT6
    random_record = ACT6.objects.order_by('?').first()
    context = {
        'username': request.user.username,
        'lives': user_profile.lives,
        'score': user_profile.score,
        'random_record': random_record
    }
    return render(request, 'act6.html', context)

#CONTROLADOR DE LA ACTIVIDAD 7
@login_required
def act7(request):
    # Obtener el perfil del usuario
    user_profile = UserProfile.objects.get(user=request.user)

    # Comprobar si el usuario tiene vidas restantes
    if user_profile.lives <= 0:
        return redirect('over')

    if request.method == 'POST':
        try:
            user_answer = int(request.POST.get('answer', 0))
            hipotenusa = int(request.POST.get('hipotenusa', 0))
        except ValueError:
            return HttpResponse("Error en la respuesta del formulario.")

        if user_answer == hipotenusa:
            user_profile.score += 1
            grade = 1
            template = 'act7success.html'
            result = 'correct'
        else:
            user_profile.lives -= 1
            grade = 0
            template = 'retroact7.html'
            result = 'incorrect'

        user_profile.save()

        StudentActivity.objects.create(
            user=request.user,
            activity_number=7,
            grade=grade,
            fecha_hora=timezone.now()
        )

        if user_profile.lives <= 0:
            return redirect('over')

        context = {
            'username': request.user.username,
            'result': result,
            'lives': user_profile.lives
        }
        return render(request, template, context)

    # Obtener un registro aleatorio de ACT7
    random_record = ACT7.objects.order_by('?').first()
    context = {
        'username': request.user.username,
        'lives': user_profile.lives,
        'score': user_profile.score,
        'random_record': random_record
    }
    return render(request, 'act7.html', context)

# CONTROLADOR DE LA ACTIVIDAD 8
@login_required
def act8(request):
    # Obtener el perfil del usuario
    user_profile = UserProfile.objects.get(user=request.user)

    # Comprobar si el usuario tiene vidas restantes
    if user_profile.lives <= 0:
        return redirect('over')

    if request.method == 'POST':
        try:
            user_answer = int(request.POST.get('answer', 0))
            lado_a = int(request.POST.get('lado_a', 0))
        except ValueError:
            return HttpResponse("Error en la respuesta del formulario.")

        # Evaluar la respuesta y actualizar el perfil del usuario
        if user_answer == lado_a:
            user_profile.score += 1
            grade = 1
            template = 'act8success.html'
            result = 'correct'
        else:
            user_profile.lives -= 1
            grade = 0
            template = 'retroact8.html'
            result = 'incorrect'

        user_profile.save()

        # Registrar la actividad del usuario
        StudentActivity.objects.create(
            user=request.user,
            activity_number=8,
            grade=grade,
            fecha_hora=timezone.now()
        )

        # Comprobar si el usuario ha perdido todas sus vidas
        if user_profile.lives <= 0:
            return redirect('over')

        context = {
            'username': request.user.username,
            'result': result,
            'lives': user_profile.lives
        }
        return render(request, template, context)

    # Obtener un registro aleatorio de ACT8
    random_record = ACT8.objects.order_by('?').first()
    context = {
        'username': request.user.username,
        'lives': user_profile.lives,
        'score': user_profile.score,
        'random_record': random_record
    }
    return render(request, 'act8.html', context)

#CONTROLADOR DE LA ACTIVIDAD 9
@login_required
def act9(request):
    # Obtener el perfil del usuario
    user_profile = UserProfile.objects.get(user=request.user)

    # Comprobar si el usuario tiene vidas restantes
    if user_profile.lives <= 0:
        return redirect('over')

    if request.method == 'POST':
        user_answer = request.POST.get('answer')
        lado_a = request.POST.get('lado_a')

        # Validar datos del formulario
        if user_answer is None or lado_a is None:
            return HttpResponse("Error en la respuesta del formulario.")

        # Evaluar la respuesta y actualizar el perfil del usuario
        if user_answer == lado_a:
            user_profile.score += 1
            grade = 1
            template = 'act9success.html'
            result = 'correct'
        else:
            user_profile.lives -= 1
            grade = 0
            template = 'retroact9.html'
            result = 'incorrect'

        user_profile.save()

        # Registrar la actividad del usuario
        StudentActivity.objects.create(
            user=request.user,
            activity_number=9,
            grade=grade,
            fecha_hora=timezone.now()
        )

        # Comprobar si el usuario ha perdido todas sus vidas
        if user_profile.lives <= 0:
            return redirect('over')

        context = {
            'username': request.user.username,
            'result': result,
            'lives': user_profile.lives
        }
        return render(request, template, context)

    # Obtener un registro aleatorio de ACTIVIDAD9
    random_record = ACTIVIDAD9.objects.order_by('?').first()
    context = {
        'username': request.user.username,
        'lives': user_profile.lives,
        'score': user_profile.score,
        'random_record': random_record
    }
    return render(request, 'act9.html', context)

# CONTROLADOR DE LA ACTIVIDAD 10
@login_required
def act10(request):
    # Obtener el perfil del usuario
    user_profile = UserProfile.objects.get(user=request.user)

    # Comprobar si el usuario tiene vidas restantes
    if user_profile.lives <= 0:
        return redirect('over')

    if request.method == 'POST':
        user_answer = request.POST.get('answer')
        hipotenusa = request.POST.get('hipotenusa')

        # Validar datos del formulario
        if user_answer is None or hipotenusa is None:
            return HttpResponse("Error en la respuesta del formulario.")

        # Evaluar la respuesta y actualizar el perfil del usuario
        if user_answer == hipotenusa:
            user_profile.score += 1
            grade = 1
            template = 'act10success.html'
            result = 'correct'
        else:
            user_profile.lives -= 1
            grade = 0
            template = 'retroact10.html'
            result = 'incorrect'

        user_profile.save()

        # Registrar la actividad del usuario
        StudentActivity.objects.create(
            user=request.user,
            activity_number=10,
            grade=grade,
            fecha_hora=timezone.now()
        )

        # Comprobar si el usuario ha perdido todas sus vidas
        if user_profile.lives <= 0:
            return redirect('over')

        context = {
            'username': request.user.username,
            'result': result,
            'lives': user_profile.lives
        }
        return render(request, template, context)

    # Obtener un registro aleatorio de ACT10
    random_record = ACT10.objects.order_by('?').first()
    context = {
        'username': request.user.username,
        'lives': user_profile.lives,
        'score': user_profile.score,
        'random_record': random_record
    }
    return render(request, 'act10.html', context)

