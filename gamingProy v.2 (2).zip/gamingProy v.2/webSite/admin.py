from django.contrib import admin
from .models import (
    rol, 
    StudentActivity, 
    UserProfile,
    ACT1,
    ACT2,
    ACT3,
    ACT4,
    ACT5,
    ACT6,
    ACT7,
    ACT8,
    ACTIVIDAD9,
    ACT10,
)

# Modelo rol
class rolAdmin(admin.ModelAdmin):
    list_display = ('user', 'rol')
    search_fields = ('user__username', 'rol')

# Modelo StudentActivity
class StudentActivityAdmin(admin.ModelAdmin):
    list_display = ('user', 'activity_number', 'grade', 'fecha_hora')
    list_filter = ('user', 'activity_number')
    date_hierarchy = 'fecha_hora'  # Permite filtrar por fechas

# Modelo UserProfile
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'score', 'lives', 'last_updated')
    search_fields = ('user__username',)
    readonly_fields = ('last_updated',)  # Campo "last_updated" solo de lectura

# Modelo ACT1
class ACT1Admin(admin.ModelAdmin):
    list_display = ('id', 'respuesta', 'descripcion', 'pregunta')
    search_fields = ('descripcion', 'pregunta')

# Modelo ACT2
class ACT2Admin(admin.ModelAdmin):
    list_display = ('id', 'respuesta', 'descripcion', 'pregunta')
    search_fields = ('descripcion', 'pregunta')

# Modelo ACT3
class ACT3Admin(admin.ModelAdmin):
    list_display = ('id', 'respuesta', 'valor_a', 'valor_b', 'valor_x', 'pregunta')
    search_fields = ('pregunta',)

# Modelo ACT4
class ACT4Admin(admin.ModelAdmin):
    list_display = ('id', 'angulo_interno', 'angulo_externo', 'pregunta')
    search_fields = ('pregunta',)

# Modelo ACT5
class ACT5Admin(admin.ModelAdmin):
    list_display = ('id', 'lado_a', 'angulo', 'pregunta')
    search_fields = ('pregunta',)

# Modelo ACT6
class ACT6Admin(admin.ModelAdmin):
    list_display = ('id', 'triangulo', 'angulo_a', 'angulo_b', 'angulo_teta', 'pregunta')
    search_fields = ('pregunta',)

# Modelo ACT7
class ACT7Admin(admin.ModelAdmin):
    list_display = ('id', 'lado_a', 'lado_b', 'hipotenusa', 'pregunta')
    search_fields = ('pregunta',)

# Modelo ACT8
class ACT8Admin(admin.ModelAdmin):
    list_display = ('id', 'lado_a', 'lado_b', 'hipotenusa', 'pregunta')
    search_fields = ('pregunta',)

# Modelo ACTIVIDAD9
class ACTIVIDAD9Admin(admin.ModelAdmin):
    list_display = ('id', 'respuesta', 'pregunta')
    search_fields = ('pregunta', 'respuesta')

# Modelo ACT10
class ACT10Admin(admin.ModelAdmin):
    list_display = ('id', 'respuesta', 'pregunta')
    search_fields = ('pregunta', 'respuesta')

admin.site.register(rol, rolAdmin)
admin.site.register(StudentActivity, StudentActivityAdmin)
admin.site.register(UserProfile, UserProfileAdmin)
admin.site.register(ACT1, ACT1Admin)
admin.site.register(ACT2, ACT2Admin)
admin.site.register(ACT3, ACT3Admin)
admin.site.register(ACT4, ACT4Admin)
admin.site.register(ACT5, ACT5Admin)
admin.site.register(ACT6, ACT6Admin)
admin.site.register(ACT7, ACT7Admin)
admin.site.register(ACT8, ACT8Admin)
admin.site.register(ACTIVIDAD9, ACTIVIDAD9Admin)
admin.site.register(ACT10, ACT10Admin)
